-- =============================================================================
-- BerufeMeister - DAS VOLLSTÄNDIGE GESAMTPAKET (1-450)
-- Alle Berufe lückenlos detailliert + Chat-Commands + Dynamische Positionierung
-- =============================================================================

-- 1. DIE DETAILLIERTE REZEPTDATENBANK (1-450)
local recipes = {
    ["Ingenieurskunst"] = {
        {min=0,   max=30,  n="Rauhes Sprengpulver", m="1x Rauher Stein"},
        {min=30,  max=50,  n="Handvoll Kupferbolzen", m="1x Kupferbarren"},
        {min=50,  max=75,  n="Kupferrohr", m="2x Kupferbarren"},
        {min=75,  max=90,  n="Grobes Sprengpulver", m="1x Grober Stein"},
        {min=90,  max=100, n="Kupfermodulator", m="2x Kupferbolzen, 1x Kupferrohr"},
        {min=100, max=105, n="Silberkontakt", m="1x Silberbarren"},
        {min=105, max=125, n="Bronzeröhre", m="2x Bronzebarren"},
        {min=125, max=150, n="Schweres Sprengpulver", m="1x Schwerer Stein"},
        {min=150, max=160, n="Bronzerahmen", m="2x Bronzebarren, 1x Wolle"},
        {min=160, max=175, n="Explosives Schaf", m="2x Schw. Pulver, 1x Bronzerahmen"},
        {min=175, max=190, n="Massives Sprengpulver", m="2x Massiver Stein"},
        {min=190, max=210, n="Große Eisenbombe", m="3x Eisen, 3x Schw. Pulver"},
        {min=210, max=225, n="Mithrilgehäuse", m="3x Mithrilbarren"},
        {min=225, max=235, n="Ungetümer Auslöser", m="1x Mithril, 1x Magiestoff"},
        {min=235, max=245, n="Hochexplosive Bombe", m="2x Gehäuse, 1x Auslöser"},
        {min=245, max=250, n="Mithrilkreisel", m="2x Mithril, 1x Eisenwolle"},
        {min=250, max=260, n="Dichtes Sprengpulver", m="2x Dichter Stein"},
        {min=260, max=290, n="Thoriumapparat", m="3x Thorium, 1x Runenstoff"},
        {min=290, max=300, n="Thoriumröhre", m="6x Thoriumbarren"},
        {min=300, max=320, n="Teufelseisenbolzen", m="1x Teufelseisen"},
        {min=320, max=335, n="Teufelseisengehäuse", m="3x Teufelseisen"},
        {min=335, max=350, n="Weiße Rauchfackel", m="1x Elementarium, 1x Stoff"},
        {min=350, max=370, n="Handvoll Kobaltbolzen", m="2x Kobaltbarren"},
        {min=370, max=385, n="Überladener Kondensator", m="4x Kobaltbarren"},
        {min=385, max=390, n="Explosivköder", m="1x Froststoff, 3x Flücht. Pulver"},
        {min=390, max=400, n="Froststahlrohr", m="8x Kobalt, 1x Kristallwasser"},
        {min=400, max=415, n="Globaler Pioniersprengsatz", m="1x Saronit, 1x Flücht. Pulver"},
        {min=415, max=430, n="Manainjektorforschung", m="12x Saronit, 2x Kristallwasser"},
        {min=430, max=450, n="Gnomisch-Arme-Messer", m="10x Saronitbarren"},
    },
    ["Alchemie"] = {
        {min=0,   max=60,  n="Schwacher Heiltrank", m="1x Friedblume, 1x Silberblatt"},
        {min=60,  max=105, n="Geringer Heiltrank", m="1x Schw. Heiltrank, 1x Wilddornrose"},
        {min=105, max=140, n="Heiltrank", m="1x Beulengras, 1x Wilddornrose"},
        {min=140, max=180, n="Geringer Manatrank", m="1x Maguskraut, 1x Würgetange"},
        {min=180, max=210, n="Großer Heiltrank", m="1x Königsblut, 1x Liferoot"},
        {min=210, max=240, n="Elixier der Agilität", m="1x Golddorn, 1x Sonnengras"},
        {min=240, max=285, n="Überragender Heiltrank", m="2x Sonnengras, 1x Khadgars Schnurrbart"},
        {min=285, max=300, n="Erheblicher Heiltrank", m="2x Golden Sansam, 1x Bergsilberweisling"},
        {min=300, max=315, n="Flüchtiges Heil-Elixier", m="1x Goldklee"},
        {min=315, max=325, n="Elixier der Heilkraft", m="1x Goldklee, 1x Tigerlilie"},
        {min=325, max=335, n="Verrückter Alchemistentrank", m="2x Goldklee"},
        {min=335, max=360, n="Elixier der tödl. Präzision", m="1x Goldklee, 1x Schlangenzunge"},
        {min=360, max=380, n="Manatrank des Wahnsinns", m="2x Talandras Rose"},
        {min=380, max=400, n="Elixier der Alpträume", m="1x Goldklee, 2x Talandras Rose"},
        {min=400, max=425, n="Unzerstörbarer Trank", m="2x Eisdorn"},
        {min=425, max=450, n="Fläschchen des Frostwyrms", m="5x Eisdorn, 5x Lichblüte, 1x Frostlotus"},
    },
    ["Schmiedekunst"] = {
        {min=0,   max=30,  n="Rauer Wetzstein", m="1x Rauher Stein"},
        {min=30,  max=75,  n="Kupferstreitkolben", m="6x Kupferbarren"},
        {min=75,  max=100, n="Grober Schleifstein", m="2x Grober Stein"},
        {min=100, max=125, n="Schwere Bronzestiefel", m="6x Bronze"},
        {min=125, max=150, n="Schwerer Schleifstein", m="3x Schwerer Stein"},
        {min=150, max=185, n="Goldene Schildstachel", m="1x Gold, 2x Eisen"},
        {min=185, max=210, n="Stahlstiefel", m="8x Stahlbarren"},
        {min=210, max=225, n="Schwere Mithrilbrustplatte", m="12x Mithril"},
        {min=225, max=250, n="Mithrilschuppenarmschienen", m="8x Mithril"},
        {min=250, max=260, n="Dichter Schleifstein", m="4x Dichter Stein"},
        {min=260, max=285, n="Thoriumarmschienen", m="8x Thorium"},
        {min=285, max=300, n="Thoriumhelm", m="12x Thorium"},
        {min=300, max=325, n="Teufelseisen-Gewichtsstein", m="1x Teufelseisen"},
        {min=325, max=350, n="Adamantit-Endstück", m="10x Adamantit"},
        {min=350, max=375, n="Kobaltstiefel", m="4x Kobalt"},
        {min=375, max=400, n="Kobaltstulpen", m="10x Kobalt"},
        {min=400, max=425, n="Saronit-Drescher", m="12x Saronit"},
        {min=425, max=450, n="Titanstahlhaube", m="4x Titanstahl, 1x Gefrorene Kugel"},
    },
    ["Schneiderei"] = {
        {min=0,   max=45,  n="Leinenstoffballen", m="2x Leinenstoff"},
        {min=45,  max=75,  n="Leinenes schweres Hemd", m="3x Leinenballen"},
        {min=75,  max=100, n="Wollstoffballen", m="3x Wollstoff"},
        {min=100, max=125, n="Einfaches Kleid", m="3x Wollballen"},
        {min=125, max=145, n="Seidenstoffballen", m="4x Seidenstoff"},
        {min=145, max=175, n="Seidenhandschuhe", m="3x Seidenballen"},
        {min=175, max=185, n="Magiestoffballen", m="4x Magiestoff"},
        {min=185, max=205, n="Purpurrote Seidenstiefel", m="4x Seidenballen"},
        {min=205, max=250, n="Schwarze Magiestoffweste", m="2x Magiestoffballen"},
        {min=250, max=260, n="Runenstoffballen", m="4x Runenstoff"},
        {min=260, max=300, n="Runenstoffhandschuhe", m="4x Runenstoffballen"},
        {min=300, max=325, n="Netherstoffballen", m="5x Netherstoff"},
        {min=325, max=350, n="Netherstoffstiefel", m="6x Netherstoffballen"},
        {min=350, max=375, n="Froststoffballen", m="5x Froststoff"},
        {min=375, max=400, n="Froststoffspritzschutz", m="1x Froststoffballen"},
        {min=400, max=425, n="Dämmergewebearmschienen", m="8x Froststoffballen"},
        {min=425, max=450, n="Froststofftasche", m="6x Verzauberter Froststoffballen"},
    },
    ["Lederverarbeitung"] = {
        {min=0,   max=35,  n="Leichtes Rüstungsset", m="1x Leichtes Leder"},
        {min=35,  max=100, n="Feiner Ledergürtel", m="6x Leichtes Leder"},
        {min=100, max=150, n="Dunkle Lederstiefel", m="4x Mittleres Leder"},
        {min=150, max=210, n="Schweres Rüstungsset", m="1x Schwerer Leder"},
        {min=210, max=250, n="Dickes Rüstungsset", m="1x Dickes Leder"},
        {min=250, max=300, n="Unverwüstliche Armschienen", m="8x Unverw. Leder"},
        {min=300, max=350, n="Knotenleder-Rüstungsset", m="4x Knotenleder"},
        {min=350, max=385, n="Boreanisches Rüstungsset", m="4x Borean. Leder"},
        {min=385, max=425, n="Arktische Stiefel", m="8x Borean. Leder"},
        {min=425, max=450, n="Trommeln der Vergeltung", m="16x Borean. Leder"},
    },
    ["Juwelenschleifen"] = {
        {min=0,   max=50,  n="Kupferkette / Tigerauge", m="Kupfer / Tigerauge"},
        {min=50,  max=100, n="Bronze / Silber Ringe", m="Bronze / Silber"},
        {min=100, max=150, n="Schwere Steinstatue", m="Schwerer Stein"},
        {min=150, max=225, n="Mithril / Zitrin Ringe", m="Mithril / Zitrin"},
        {min=225, max=300, n="Thorium / Rubin Ringe", m="Thorium / Rubin"},
        {min=300, max=350, n="Azurmondsteinring", m="Azurmondstein"},
        {min=350, max=410, n="Nordend-Edelsteine", m="Rohedelsteine"},
        {min=410, max=450, n="Schattenmacht / Irdener Ring", m="Ewiger Schatten / Erde"},
    },
    ["Inschriftenkunde"] = {
        {min=0,   max=35,  n="Elfenbein/Mondschimmertinte", m="Alabasterpigment"},
        {min=35,  max=100, n="Mitternachtstinte / Glyphen", m="Trübes Pigment"},
        {min=100, max=150, n="Löwentinte", m="Goldenes Pigment"},
        {min=150, max=200, n="Jadesturmtinte", m="Smaragdgrünes Pigment"},
        {min=200, max=300, n="Himmelsglanz-Tinte", m="Violettes Pigment"},
        {min=300, max=350, n="Ätherische Tinte", m="Teufelspigment"},
        {min=350, max=400, n="Tinte des Meeres", m="Azurpigment"},
        {min=400, max=450, n="Schneefalltinte / Karten", m="Icy Pigment"},
    },
    ["Verzauberkunst"] = {
        {min=0,   max=75,  n="Armschiene - Gesundheit", m="Seltsamer Staub"},
        {min=75,  max=150, n="Armschiene - Geringe Ausdauer", m="Seelenstaub"},
        {min=150, max=225, n="Armschiene - Intelligenz", m="Visionstaub"},
        {min=225, max=300, n="Armschiene - Große Ausdauer", m="Traumstaub"},
        {min=300, max=350, n="Armschiene - Sturmangriff", m="Arkaner Staub"},
        {min=350, max=450, n="Armschiene - Große Werte", m="Unendlicher Staub"},
    },
    ["Bergbau"] = {
        {min=1,   max=65,  n="Kupfer", m="Startgebiete"},
        {min=65,  max=125, n="Zinn / Silber", m="Vorgebirge / Eschental"},
        {min=125, max=175, n="Eisen / Gold", m="Arathi / Desolace"},
        {min=175, max=230, n="Mithril / Echtsilber", m="Ödland / Teufelswald"},
        {min=230, max=300, n="Thorium", m="Un'Goro / Silithus"},
        {min=300, max=350, n="Teufelseisen / Adamantit", m="Höllenfeuer / Nagrand"},
        {min=350, max=450, n="Kobalt / Saronit / Titan", m="Ganz Nordend"},
    },
    ["Kräuterkunde"] = {
        {min=1,   max=75,  n="Friedblume / Silberblatt", m="Startgebiete"},
        {min=75,  max=150, n="Wilddornrose / Beulengras", m="Classic"},
        {min=150, max=230, n="Golddorn / Blassblatt", m="Düsterw. / Arathi"},
        {min=230, max=300, n="Sonnengras / Traumblatt", m="Pestländer"},
        {min=300, max=350, n="Teufelsgras / Traumwinde", m="Scherbenwelt"},
        {min=350, max=450, n="Goldklee / Frostlotus", m="Nordend"},
    }
}

-- 2. HAUPTFENSTER SETUP
local frame = CreateFrame("Frame", "BerufeMeisterFrame", UIParent)
frame:SetSize(240, 100)
frame:SetPoint("CENTER")
frame:SetBackdrop({
    bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 16,
    insets = {left=4, right=4, top=4, bottom=4}
})
frame:EnableMouse(true); frame:SetMovable(true); frame:SetClampedToScreen(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

-- Zahnrad-Button
local settingsBtn = CreateFrame("Button", nil, frame)
settingsBtn:SetSize(18, 18); settingsBtn:SetPoint("TOPRIGHT", -10, -12)
local tex = settingsBtn:CreateTexture(nil, "BACKGROUND")
tex:SetTexture("Interface\\Icons\\Trade_Engineering"); tex:SetAllPoints(settingsBtn)
settingsBtn:SetNormalTexture(tex)

-- Textelemente initialisieren
local lines = {}
for i=1, 5 do
    lines[i] = {}
    lines[i].title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lines[i].rec = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lines[i].rec:SetTextColor(0, 1, 1)
    lines[i].mats = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lines[i].mats:SetTextColor(0.8, 0.8, 0.8)
end
local ammoText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
local bagText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")

-- 3. CHAT BEFEHLE
SLASH_BERUFEMEISTER1 = "/bm"
SLASH_BERUFEMEISTER2 = "/berufemeister"
SLASH_BERUFEMEISTER3 = "/meister"
SlashCmdList["BERUFEMEISTER"] = function(msg)
    if msg == "reset" then
        frame:ClearAllPoints()
        frame:SetPoint("CENTER", UIParent, "CENTER")
        frame:Show()
        BerufeMeisterDB.shown = true
        print("|cFF00FF00BerufeMeister:|r Position zurückgesetzt.")
    elseif frame:IsShown() then
        frame:Hide()
        BerufeMeisterDB.shown = false
    else
        frame:Show()
        BerufeMeisterDB.shown = true
    end
end

-- 4. DATENBANK INITIALISIERUNG
local allProfs = {"Kürschnerei", "Lederverarbeitung", "Bergbau", "Schmiedekunst", "Kräuterkunde", "Alchemie", "Ingenieurskunst", "Verzauberkunst", "Juwelenschleifen", "Inschriftenkunde", "Schneiderei", "Kochkunst", "Erste Hilfe", "Angeln"}

frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(self, event, addonName)
    if addonName == "BerufeMeister" then
        if not BerufeMeisterDB then
            BerufeMeisterDB = { warnPet = true, warnAmmo = true, warnBags = true, shown = true }
            for _, p in ipairs(allProfs) do BerufeMeisterDB["warn"..p] = true end
        end
        if BerufeMeisterDB.shown then frame:Show() else frame:Hide() end
    end
end)

-- 5. EINSTELLUNGS-MENÜ
local optFrame = CreateFrame("Frame", nil, UIParent)
optFrame:SetSize(200, 250); optFrame:Hide()
optFrame:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile="Interface\\Tooltips\\UI-Tooltip-Border", tile=true, tileSize=16, edgeSize=16, insets={left=4,right=4,top=4,bottom=4}})
optFrame:SetFrameStrata("HIGH")

local checkButtons = {}
local function GetCB(label, key)
    if _G["BM_CB_"..key] then return _G["BM_CB_"..key] end
    local cb = CreateFrame("CheckButton", "BM_CB_"..key, optFrame, "UICheckButtonTemplate")
    cb:SetSize(20, 20); _G[cb:GetName().."Text"]:SetText(label); cb.configKey = key
    table.insert(checkButtons, cb); return cb
end

settingsBtn:SetScript("OnClick", function()
    if optFrame:IsShown() then optFrame:Hide() else
        for _, cb in ipairs(checkButtons) do cb:Hide() end
        local y = -15; local _, cl = UnitClass("player")
        if cl == "HUNTER" then
            local c1 = GetCB("Pet füttern", "warnPet"); c1:SetPoint("TOPLEFT", 15, y); c1:Show(); c1:SetChecked(BerufeMeisterDB.warnPet); y = y - 20
            local c2 = GetCB("Munition", "warnAmmo"); c2:SetPoint("TOPLEFT", 15, y); c2:Show(); c2:SetChecked(BerufeMeisterDB.warnAmmo); y = y - 20
        end
        local c3 = GetCB("Taschen", "warnBags"); c3:SetPoint("TOPLEFT", 15, y); c3:Show(); c3:SetChecked(BerufeMeisterDB.warnBags); y = y - 25
        for i = 1, GetNumSkillLines() do
            local n = GetSkillLineInfo(i)
            for _, p in ipairs(allProfs) do if n == p then
                local cb = GetCB(n, "warn"..n); cb:SetPoint("TOPLEFT", 15, y); cb:Show(); cb:SetChecked(BerufeMeisterDB["warn"..n]); y = y - 22
            end end
        end
        
        -- DYNAMISCHE POSITIONIERUNG
        optFrame:ClearAllPoints()
        if frame:GetCenter() > (GetScreenWidth() / 2) then
            optFrame:SetPoint("RIGHT", frame, "LEFT", -10, 0)
        else
            optFrame:SetPoint("LEFT", frame, "RIGHT", 10, 0)
        end
        optFrame:SetHeight(math.abs(y) + 60); optFrame:Show()
    end
end)

local saveBtn = CreateFrame("Button", nil, optFrame, "UIPanelButtonTemplate")
saveBtn:SetSize(100, 22); saveBtn:SetPoint("BOTTOM", 0, 15); saveBtn:SetText("Speichern")
saveBtn:SetScript("OnClick", function() 
    for _, cb in ipairs(checkButtons) do if cb:IsShown() then BerufeMeisterDB[cb.configKey] = cb:GetChecked() end end
    optFrame:Hide() 
end)

-- 6. UPDATE SCHLEIFE
frame:SetScript("OnUpdate", function(self, elapsed)
    self.timer = (self.timer or 0) + elapsed
    if self.timer < 1.0 then return end; self.timer = 0
    if not BerufeMeisterDB or not self:IsShown() then return end

    for i=1, 5 do lines[i].title:Hide(); lines[i].rec:Hide(); lines[i].mats:Hide() end
    ammoText:Hide(); bagText:Hide()

    local y = -12; local lIdx = 1
    for i = 1, GetNumSkillLines() do
        local name, _, _, rank, _, _, maxRank = GetSkillLineInfo(i)
        if BerufeMeisterDB["warn"..name] and lIdx <= 5 then
            local line = lines[lIdx]
            local warn = (maxRank > 0 and (maxRank - rank) <= 5 and maxRank < 450) and " |cFFFF0000(LEHRER!)|r" or ""
            
            -- Skillpunkte in WEISS
            line.title:SetPoint("TOPLEFT", 12, y)
            line.title:SetText(name..": |cFFFFFFFF"..rank.."/"..maxRank.."|r"..warn)
            line.title:Show(); y = y - 13
            
            if recipes[name] then
                for _, data in ipairs(recipes[name]) do
                    if rank >= data.min and rank < data.max then
                        line.rec:SetPoint("TOPLEFT", 22, y); line.rec:SetText("> "..data.n); line.rec:Show(); y = y - 12
                        line.mats:SetPoint("TOPLEFT", 22, y); line.mats:SetText("  "..data.m); line.mats:Show(); y = y - 12
                        break
                    end
                end
            end
            lIdx = lIdx + 1; y = y - 4
        end
    end

    local _, cl = UnitClass("player")
    if (cl == "HUNTER" or cl == "WARRIOR" or cl == "ROGUE") and BerufeMeisterDB.warnAmmo then
        local ammo = GetInventoryItemCount("player", 0)
        ammoText:SetPoint("TOPLEFT", 12, y); ammoText:SetText("Munition: |cFFFFFFFF"..ammo.."|r"); ammoText:Show(); y = y - 13
    end
    if BerufeMeisterDB.warnBags then
        local free = 0; for i=0,4 do local s, t = GetContainerNumFreeSlots(i); if t==0 then free = free + s end end
        bagText:SetPoint("TOPLEFT", 12, y); bagText:SetText("Freie Plätze: |cFFFFFFFF"..free.."|r"); bagText:Show(); y = y - 13
    end
    self:SetHeight(math.abs(y) + 15)
end)